export type Role = "personnel" | "admin";

export interface User {
  id: string; // Personnel ID, e.g. "PN-2201"
  name: string;
  role: Role;
  unit?: string;
}

export interface CategoryScores {
  [category: string]: number; // 0-100
}

export interface Screening {
  id: string;
  userId: string;
  date: string; // ISO string
  categoryScores: CategoryScores;
  overall: number; // 0-100
  observations: string[];
}

export type RiskLevel = "low" | "moderate" | "high";

export interface RiskInfo {
  key: RiskLevel;
  label: string;
}

export interface ConsultationRequest {
  id: string;
  userId: string;
  mode: "in-person" | "remote";
  locationId?: string;
  remoteType?: "video" | "phone";
  requestedFor: string; // free-text date/time chosen by the user
  status: "pending" | "scheduled" | "completed";
  createdAt: string;
}

export interface Alert {
  id: string;
  userId: string;
  level: "follow-up" | "priority-follow-up";
  message: string;
  status: "open" | "acknowledged" | "assigned" | "resolved";
  createdAt: string;
}

export interface ExpressionReading {
  key: "positive" | "neutral" | "concerned" | "surprised";
  label: string;
  emoji: string;
  confidence: number;
  t: number;
}

export interface AuditLogEntry {
  id: string;
  actorId: string;
  action: string;
  target?: string;
  createdAt: string;
}
