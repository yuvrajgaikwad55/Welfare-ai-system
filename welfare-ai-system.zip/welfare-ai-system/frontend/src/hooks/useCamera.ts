import { useRef, useState, useCallback, useEffect } from "react";

export type CameraStatus = "idle" | "requesting" | "active" | "error";

export type CameraErrorType =
  | "NotAllowedError"
  | "NotFoundError"
  | "NotReadableError"
  | "SecurityError"
  | "insecureContext"
  | "unsupported"
  | "unknown";

export const CAMERA_ERROR_MESSAGES: Record<CameraErrorType, string> = {
  NotAllowedError:
    "Camera permission is blocked. Chrome: click the site controls/lock icon → Camera → Allow → Reload the page → Retry Camera.",
  NotFoundError: "No camera device was detected.",
  NotReadableError:
    "Your camera may already be in use by another application. Close Zoom, Teams, Meet, etc. and try again.",
  SecurityError: "Your browser blocked this request due to a security restriction.",
  insecureContext: "Camera access requires HTTPS or localhost.",
  unsupported: "This browser doesn't support camera access (getUserMedia is unavailable).",
  unknown: "Camera access failed. Please try again.",
};

export interface CameraDiagnostics {
  apiAvailable: boolean;
  secureContext: boolean;
  permissionState: PermissionState | "unknown";
  streamActive: boolean;
}

/**
 * Real camera hook — no simulation, no fake frames.
 *
 * Behaviour:
 *  - Never requests permission on mount. Only `start()` (called from a
 *    user click) invokes getUserMedia.
 *  - Distinguishes NotAllowedError / NotFoundError / NotReadableError /
 *    SecurityError / insecure-context / unsupported-browser.
 *  - Cleans up all MediaStream tracks on stop() and on unmount.
 *
 * This hook will behave identically whether run on http://localhost:5173
 * or a real https:// deployment. It will NOT get a live stream inside a
 * sandboxed iframe (like Claude's Artifacts preview) because iframes
 * without an explicit `allow="camera"` permissions policy are blocked by
 * the browser itself — that's a browser security boundary, not a bug in
 * this hook.
 */
export function useCamera() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [status, setStatus] = useState<CameraStatus>("idle");
  const [errorType, setErrorType] = useState<CameraErrorType | null>(null);
  const [permissionState, setPermissionState] = useState<PermissionState | "unknown">("unknown");

  const isSecureContext = typeof window !== "undefined" ? window.isSecureContext : false;
  const apiAvailable = typeof navigator !== "undefined" && !!navigator.mediaDevices && !!navigator.mediaDevices.getUserMedia;

  // Read-only permission check — never triggers the browser's camera prompt.
  useEffect(() => {
    let sub: PermissionStatus | undefined;
    if (navigator.permissions && (navigator.permissions as any).query) {
      navigator.permissions
        .query({ name: "camera" as PermissionName })
        .then((result) => {
          sub = result;
          setPermissionState(result.state);
          result.onchange = () => setPermissionState(result.state);
        })
        .catch(() => setPermissionState("unknown"));
    }
    return () => {
      if (sub) sub.onchange = null;
    };
  }, []);

  const stop = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    setStatus((s) => (s === "active" ? "idle" : s));
  }, []);

  const start = useCallback(async () => {
    setErrorType(null);

    if (!isSecureContext) {
      setErrorType("insecureContext");
      setStatus("error");
      return;
    }
    if (!apiAvailable) {
      setErrorType("unsupported");
      setStatus("error");
      return;
    }

    setStatus("requesting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {
          /* autoplay can reject silently in some browsers until user gesture settles; ignore */
        });
      }
      setStatus("active");
    } catch (e: any) {
      const name = e?.name as string | undefined;
      const mapped: CameraErrorType =
        name === "NotAllowedError" ? "NotAllowedError"
        : name === "NotFoundError" ? "NotFoundError"
        : name === "NotReadableError" ? "NotReadableError"
        : name === "SecurityError" ? "SecurityError"
        : "unknown";
      setErrorType(mapped);
      setStatus("error");
      // Development diagnostics only — never logs frame data or personal info.
      console.error("[camera] getUserMedia failed:", name || e);
    }
  }, [isSecureContext, apiAvailable]);

  // Always release the camera when the component unmounts / page changes.
  useEffect(() => () => stop(), [stop]);

  const diagnostics: CameraDiagnostics = {
    apiAvailable,
    secureContext: isSecureContext,
    permissionState,
    streamActive: status === "active",
  };

  return {
    videoRef,
    status,
    errorType,
    errorMessage: errorType ? CAMERA_ERROR_MESSAGES[errorType] : null,
    permissionState,
    diagnostics,
    start,
    stop,
  };
}
