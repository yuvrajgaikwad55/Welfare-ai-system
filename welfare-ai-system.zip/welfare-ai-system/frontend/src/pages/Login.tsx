import { useState, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { Shield, Eye, EyeOff, Lock } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Button } from "../components/ui";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(id, password);
      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message || "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-navy flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <div className="w-12 h-12 rounded-xl bg-accent-dim flex items-center justify-center mb-3">
            <Shield size={24} className="text-accent" />
          </div>
          <h1 className="text-lg font-bold text-ink">Personnel Welfare AI</h1>
          <p className="text-xs text-ink-faint mt-1 flex items-center gap-1">
            <Lock size={11} /> Secure access
          </p>
        </div>

        <form onSubmit={handleSubmit} className="bg-navy-surface border border-line rounded-lg p-6 flex flex-col gap-4">
          <div>
            <label className="text-xs text-ink-dim mb-1.5 block">Personnel ID</label>
            <input
              value={id}
              onChange={(e) => setId(e.target.value)}
              placeholder="PN-2201"
              className="w-full bg-navy border border-line rounded-md px-3 py-2.5 text-sm text-ink outline-none focus:border-accent"
              autoFocus
            />
          </div>
          <div>
            <label className="text-xs text-ink-dim mb-1.5 block">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-navy border border-line rounded-md px-3 py-2.5 text-sm text-ink outline-none focus:border-accent pr-9"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-faint"
              >
                {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs">
            <label className="flex items-center gap-2 text-ink-dim">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              Remember me
            </label>
            <button type="button" className="text-accent hover:underline">Forgot password?</button>
          </div>

          {error && <div className="text-xs text-bad bg-bad-dim border border-bad/30 rounded-md px-3 py-2">{error}</div>}

          <Button type="submit" disabled={loading} className="w-full justify-center">
            {loading ? "Signing in…" : "Login"}
          </Button>

          {import.meta.env.DEV && (
            <div className="text-[11px] text-ink-faint bg-navy border border-line rounded-md px-3 py-2 leading-relaxed">
              <strong className="text-ink-dim">Demo credentials</strong><br />
              Personnel: <code>PN-2201</code> / Admin: <code>ADM-01</code><br />
              Password (both): <code>demo1234</code>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
