import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useAuth } from "../context/AuthContext";
import { getCategoryTrend, getWellnessTrend } from "../lib/store";
import { QUESTIONS } from "../lib/scoring";
import { Panel, PageHeader, EmptyState } from "../components/ui";

const RANGES = [
  { key: 7, label: "7 Days" },
  { key: 30, label: "30 Days" },
  { key: 90, label: "90 Days" },
];

const CATEGORY_ICONS: Record<string, string> = {
  "Sleep & Recovery": "😴",
  Workload: "🎯",
  Mood: "😊",
  "Social Support": "🤝",
  "Work-Life Balance": "⚖️",
  "Recovery & Wellbeing": "🌿",
};

function TrendChart({ title, data, dataKey }: { title: string; data: any[]; dataKey: string }) {
  return (
    <Panel>
      <div className="text-sm font-semibold mb-4">{title}</div>
      {data.length >= 2 ? (
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={data}>
            <CartesianGrid stroke="#1E2C3D" vertical={false} />
            <XAxis dataKey="date" stroke="#5E7188" fontSize={11} tickLine={false} />
            <YAxis stroke="#5E7188" fontSize={11} domain={[0, 100]} tickLine={false} axisLine={false} width={28} />
            <Tooltip contentStyle={{ background: "#1B2838", border: "1px solid #26374B", borderRadius: 6, fontSize: 12 }} />
            <Line type="monotone" dataKey={dataKey} stroke="#4C93C7" strokeWidth={2.5} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <EmptyState text="Not enough screenings in this range yet." />
      )}
    </Panel>
  );
}

export default function Analytics() {
  const { user } = useAuth();
  const [range, setRange] = useState(30);
  if (!user) return null;

  const wellnessTrend = getWellnessTrend(user.id, range);
  const categories = Object.keys(QUESTIONS);

  return (
    <div>
      <PageHeader
        title="Analytics"
        sub="All charts below are generated from your actual submitted screenings."
        right={
          <div className="flex gap-2">
            {RANGES.map((r) => (
              <button
                key={r.key}
                onClick={() => setRange(r.key)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold border ${
                  range === r.key ? "bg-accent-dim border-accent text-accent" : "border-line text-ink-dim"
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TrendChart title="📈 Wellness Trend" data={wellnessTrend} dataKey="overall" />
        {categories.slice(0, 4).map((cat) => (
          <TrendChart
            key={cat}
            title={`${CATEGORY_ICONS[cat] || ""} ${cat} Trend`}
            data={getCategoryTrend(user.id, cat, range)}
            dataKey="value"
          />
        ))}
      </div>
    </div>
  );
}
