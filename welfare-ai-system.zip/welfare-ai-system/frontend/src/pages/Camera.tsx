import { useState, useEffect, useRef } from "react";
import { Camera as CameraIcon, Info, Lock, ChevronDown, ChevronUp } from "lucide-react";
import { useCamera } from "../hooks/useCamera";
import { Panel, Badge, Button, PageHeader, ProgressBar } from "../components/ui";

interface ExpressionReading {
  key: "positive" | "neutral" | "concerned" | "surprised";
  label: string;
  emoji: string;
  confidence: number;
}

const EXPRESSIONS: ExpressionReading[] = [
  { key: "positive", label: "Positive", emoji: "😊", confidence: 0 },
  { key: "neutral", label: "Neutral", emoji: "😐", confidence: 0 },
  { key: "concerned", label: "Concern signal", emoji: "😟", confidence: 0 },
  { key: "surprised", label: "Surprised", emoji: "😮", confidence: 0 },
];

export default function CameraCheck() {
  const { videoRef, status, errorMessage, permissionState, diagnostics, start, stop } = useCamera();
  const [current, setCurrent] = useState<ExpressionReading | null>(null);
  const [history, setHistory] = useState<ExpressionReading[]>([]);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const intervalRef = useRef<number | null>(null);

  // DEMO/PROTOTYPE expression signal: this is a placeholder generator, not a
  // real facial-expression model. The architecture (this effect + the
  // ExpressionReading shape) is ready to be swapped for a real client-side
  // model (e.g. a TensorFlow.js face-landmark model run on video frames)
  // without changing anything else on this page.
  useEffect(() => {
    if (status !== "active") return;
    intervalRef.current = window.setInterval(() => {
      const weights = [0.5, 0.27, 0.13, 0.10];
      const r = Math.random();
      let idx = weights.length - 1, acc = 0;
      for (let i = 0; i < weights.length; i++) { acc += weights[i]; if (r < acc) { idx = i; break; } }
      const reading: ExpressionReading = { ...EXPRESSIONS[idx], confidence: Math.round(60 + Math.random() * 35) };
      setCurrent(reading);
      setHistory((h) => [reading, ...h].slice(0, 8));
    }, 2600);
    return () => { if (intervalRef.current) window.clearInterval(intervalRef.current); };
  }, [status]);

  const counts = EXPRESSIONS.map((e) => ({
    ...e,
    pct: history.length ? Math.round((history.filter((h) => h.key === e.key).length / history.length) * 100) : 0,
  }));

  const blockedBeforeAsking = permissionState === "denied" && status === "idle";

  return (
    <div>
      <PageHeader
        title="Camera Check"
        sub="AI-assisted expression & wellness signal — an optional, weak signal alongside your screening responses."
        right={<Badge tone="warn"><Info size={12} /> Demo/prototype signal</Badge>}
      />

      <div className="flex gap-4 flex-wrap">
        <Panel className="flex-[2] min-w-[340px]">
          <div className="relative aspect-[4/3] bg-black rounded-md overflow-hidden border border-line flex items-center justify-center mb-4">
            {status === "active" ? (
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            ) : (
              <div className="text-center text-ink-faint text-xs px-6 max-w-[300px]">
                <CameraIcon size={26} className="mx-auto mb-2 opacity-60" />
                {status === "requesting" && <div>Requesting camera access…</div>}
                {status === "error" && <div className="text-warn">{errorMessage}</div>}
                {status === "idle" && (
                  <div>Camera access is optional. Allow camera access to enable the AI-assisted expression wellness feature.</div>
                )}
              </div>
            )}
            {status === "active" && (
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 bg-black/60 px-2.5 py-1 rounded text-[11px] font-semibold text-good">
                🟢 Camera Active
              </div>
            )}
          </div>

          {blockedBeforeAsking && (
            <div className="flex gap-2 items-start px-3 py-2.5 rounded-md bg-warn-dim border border-warn/30 text-xs text-ink-dim mb-3">
              <Lock size={14} className="text-warn shrink-0 mt-0.5" />
              Camera permission is blocked. Click the site controls/lock icon in your browser's address bar → Camera →
              Allow → Reload the page → Retry Camera.
            </div>
          )}

          <div className="flex gap-3 flex-wrap">
            {status !== "active" ? (
              <Button icon={CameraIcon} onClick={start} disabled={status === "requesting"}>
                📷 {status === "error" ? "Retry Camera" : "Start Camera"}
              </Button>
            ) : (
              <Button icon={CameraIcon} variant="secondary" onClick={stop}>⏹ Stop Camera</Button>
            )}
          </div>
        </Panel>

        <Panel className="flex-[1] min-w-[260px]">
          <div className="text-sm text-ink-dim mb-2">Current expression</div>
          {current ? (
            <>
              <div className="flex items-center gap-3 mb-1.5">
                <span className="text-3xl">{current.emoji}</span>
                <div className="text-lg font-semibold">{current.label}</div>
              </div>
              <div className="text-xs text-ink-faint mb-4">Confidence: {current.confidence}%</div>
            </>
          ) : (
            <div className="text-sm text-ink-faint mb-4">
              {status === "active" ? "Waiting for first reading…" : "Start the camera to see live readings."}
            </div>
          )}

          <div className="text-sm text-ink-dim mb-2.5">Recent observations</div>
          {counts.map((c) => (
            <div key={c.key} className="mb-2.5">
              <div className="flex justify-between text-xs mb-1">
                <span>{c.emoji} {c.label}</span>
                <span className="text-ink-dim">{c.pct}%</span>
              </div>
              <ProgressBar value={c.pct} />
            </div>
          ))}
        </Panel>
      </div>

      {/* Collapsible developer diagnostics panel */}
      <Panel className="mt-4">
        <button
          onClick={() => setShowDiagnostics((s) => !s)}
          className="w-full flex items-center justify-between text-sm font-semibold text-ink-dim"
        >
          Camera diagnostics
          {showDiagnostics ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        {showDiagnostics && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs">
            <DiagRow label="Camera API" value={diagnostics.apiAvailable ? "Available" : "Unavailable"} ok={diagnostics.apiAvailable} />
            <DiagRow label="Secure Context" value={diagnostics.secureContext ? "Yes" : "No"} ok={diagnostics.secureContext} />
            <DiagRow label="Permission" value={diagnostics.permissionState} ok={diagnostics.permissionState === "granted"} />
            <DiagRow label="Camera Stream" value={diagnostics.streamActive ? "Active" : "Inactive"} ok={diagnostics.streamActive} />
          </div>
        )}
      </Panel>

      <Panel className="mt-4 flex gap-3 items-start">
        <Info size={16} className="text-ink-faint shrink-0 mt-0.5" />
        <p className="text-xs text-ink-faint leading-relaxed">
          Camera access is optional. Video is not recorded or uploaded by this feature — all processing happens
          locally in your browser and the stream is discarded when you stop the camera or leave this page. Expression
          signal is one optional, weak indicator and should not be interpreted on its own — it is never used to
          diagnose depression, anxiety, stress disorders, or any medical condition, and is weighted far less than
          your questionnaire responses in any combined assessment.
        </p>
      </Panel>
    </div>
  );
}

function DiagRow({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <div className="bg-navy border border-line rounded-md p-3">
      <div className="text-ink-faint mb-1">{label}</div>
      <div className={ok ? "text-good font-semibold" : "text-warn font-semibold"}>{value}</div>
    </div>
  );
}
