import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Save } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { QUESTIONS, OPTIONS } from "../lib/scoring";
import { submitScreening } from "../lib/store";
import { Panel, Button, PageHeader } from "../components/ui";

const SECTION_ICONS: Record<string, string> = {
  "Sleep & Recovery": "😴",
  Workload: "🎯",
  Mood: "😊",
  "Social Support": "🤝",
  "Work-Life Balance": "⚖️",
  "Recovery & Wellbeing": "🌿",
};

const DRAFT_KEY = "welfare_ai_screening_draft";

export default function Screening() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const categories = Object.keys(QUESTIONS);
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, Record<number, number>>>(() => {
    const raw = localStorage.getItem(DRAFT_KEY);
    return raw ? JSON.parse(raw) : {};
  });
  const [submitting, setSubmitting] = useState(false);

  const category = categories[step];
  const questions = QUESTIONS[category];

  function setAnswer(qIndex: number, value: number) {
    setAnswers((prev) => ({ ...prev, [category]: { ...prev[category], [qIndex]: value } }));
  }

  function saveDraft() {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(answers));
  }

  async function handleSubmit() {
    if (!user) return;
    setSubmitting(true);
    try {
      const screening = await submitScreening(user.id, answers);
      localStorage.removeItem(DRAFT_KEY);
      navigate(`/reports?highlight=${screening.id}`);
    } finally {
      setSubmitting(false);
    }
  }

  const answeredInSection = Object.keys(answers[category] || {}).length;
  const isLastStep = step === categories.length - 1;
  const canProceed = answeredInSection === questions.length;

  return (
    <div>
      <PageHeader title="Wellness Screening" sub={`Step ${step + 1} of ${categories.length}`} />

      <div className="w-full h-1.5 bg-navy-raised rounded-full mb-6 overflow-hidden">
        <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${((step + 1) / categories.length) * 100}%` }} />
      </div>

      <Panel className="max-w-2xl">
        <div className="text-lg font-semibold mb-5">{SECTION_ICONS[category]} {category}</div>

        <div className="flex flex-col gap-6">
          {questions.map((q, qi) => (
            <div key={qi}>
              <div className="text-sm text-ink-dim mb-3">{q}</div>
              <div className="flex gap-2 flex-wrap">
                {OPTIONS.map((opt) => (
                  <button
                    key={opt.v}
                    onClick={() => setAnswer(qi, opt.v)}
                    className={`flex flex-col items-center gap-1 px-3 py-2.5 rounded-md border text-xs min-w-[76px] transition ${
                      answers[category]?.[qi] === opt.v
                        ? "bg-accent-dim border-accent text-accent"
                        : "bg-navy border-line text-ink-dim hover:border-accent/50"
                    }`}
                  >
                    <span className="text-lg">{opt.emoji}</span>
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between mt-8 pt-5 border-t border-line">
          <Button variant="ghost" icon={ChevronLeft} disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
            Previous
          </Button>
          <div className="flex gap-2">
            <Button variant="secondary" icon={Save} onClick={saveDraft}>Save Draft</Button>
            {isLastStep ? (
              <Button disabled={!canProceed || submitting} onClick={handleSubmit}>
                {submitting ? "Submitting…" : "Submit Screening"}
              </Button>
            ) : (
              <Button icon={ChevronRight} disabled={!canProceed} onClick={() => setStep((s) => s + 1)}>
                Next
              </Button>
            )}
          </div>
        </div>
      </Panel>

      <p className="text-xs text-ink-faint mt-4 max-w-2xl">
        This screening provides a wellbeing support indicator only — it is not a medical diagnosis. If you are in
        crisis or need immediate help, contact emergency services or a crisis helpline right away.
      </p>
    </div>
  );
}
