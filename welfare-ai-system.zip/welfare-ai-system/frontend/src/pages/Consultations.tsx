import { useState } from "react";
import { MapPin, Video, Phone, Calendar, Stethoscope, CheckCircle2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getLatestScreening, getConsultations, requestConsultation } from "../lib/store";
import { consultationRecommendationFor } from "../lib/scoring";
import { Panel, Badge, Button, PageHeader, EmptyState } from "../components/ui";

const LOCATIONS = [
  { id: "base-clinic", name: "Base Medical Center", distance: "On-site" },
  { id: "station-clinic", name: "Station Wellness Clinic", distance: "12 km away" },
  { id: "civil-hospital", name: "Nearby Civil Hospital (referral)", distance: "18 km away" },
];
const TIME_SLOTS = ["Today, 4:30 PM", "Today, 6:00 PM", "Tomorrow, 9:00 AM", "Tomorrow, 11:30 AM", "Wed, 10:00 AM"];
const CONSULT_PHONE = "8208528296";

export default function Consultations() {
  const { user } = useAuth();
  const [mode, setMode] = useState<"in-person" | "remote">("in-person");
  const [locationId, setLocationId] = useState(LOCATIONS[0].id);
  const [remoteType, setRemoteType] = useState<"video" | "phone">("video");
  const [slot, setSlot] = useState<string | null>(null);
  const [customDate, setCustomDate] = useState("");
  const [customTime, setCustomTime] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (!user) return null;
  const latest = getLatestScreening(user.id);
  const rec = consultationRecommendationFor(latest?.overall ?? 74);
  const history = getConsultations(user.id);

  const customSlot = customDate && customTime
    ? new Date(`${customDate}T${customTime}`).toLocaleString("en-IN", { weekday: "short", day: "2-digit", month: "short", hour: "numeric", minute: "2-digit" })
    : null;
  const effectiveSlot = customSlot || slot;

  async function handleRequest() {
    if (!effectiveSlot || !user) return;
    await requestConsultation({
      userId: user.id,
      mode,
      locationId: mode === "in-person" ? locationId : undefined,
      remoteType: mode === "remote" ? remoteType : undefined,
      requestedFor: effectiveSlot,
    });
    setSubmitted(true);
  }

  return (
    <div>
      <PageHeader title="Consultations" sub="Request a wellness consultation, counselling appointment, or general welfare support." />

      <Panel className="mb-5 border-l-[3px]" style={{ borderLeftColor: "#4C93C7" }}>
        <div className="flex justify-between items-center mb-2">
          <div className="font-semibold text-sm">{rec.type} recommended</div>
          <Badge>{rec.urgency}</Badge>
        </div>
        <p className="text-sm text-ink-dim">{rec.note} Suggested with: {rec.professional}.</p>
      </Panel>

      <Panel className="max-w-xl mb-6">
        <div className="text-xs font-semibold text-ink-faint mb-2">How would you like to consult?</div>
        <div className="flex gap-2 mb-4">
          <button onClick={() => setMode("in-person")} className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm ${mode === "in-person" ? "border-accent bg-accent-dim text-accent" : "border-line text-ink-dim"}`}>
            <MapPin size={14} /> In person
          </button>
          <button onClick={() => setMode("remote")} className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm ${mode === "remote" ? "border-accent bg-accent-dim text-accent" : "border-line text-ink-dim"}`}>
            <Video size={14} /> Remote
          </button>
        </div>

        {mode === "in-person" ? (
          <div className="flex gap-2 flex-wrap mb-4">
            {LOCATIONS.map((l) => (
              <button key={l.id} onClick={() => setLocationId(l.id)} className={`flex flex-col items-start px-3 py-2 rounded-md border min-w-[150px] ${locationId === l.id ? "border-accent bg-accent-dim" : "border-line"}`}>
                <span className="text-sm font-semibold">{l.name}</span>
                <span className="text-xs text-ink-faint">{l.distance}</span>
              </button>
            ))}
          </div>
        ) : (
          <div className="mb-4">
            <div className="flex gap-2 mb-2">
              <button onClick={() => setRemoteType("video")} className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm ${remoteType === "video" ? "border-accent bg-accent-dim text-accent" : "border-line text-ink-dim"}`}>
                <Video size={14} /> Video
              </button>
              <button onClick={() => setRemoteType("phone")} className={`flex items-center gap-2 px-3 py-2 rounded-md border text-sm ${remoteType === "phone" ? "border-accent bg-accent-dim text-accent" : "border-line text-ink-dim"}`}>
                <Phone size={14} /> Phone
              </button>
            </div>
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-md bg-accent-dim border border-accent/30 text-sm">
              <Phone size={14} className="text-accent" />
              {remoteType === "video" ? "Video consultation number: " : "Call this number: "}
              <span className="font-bold">{CONSULT_PHONE}</span>
            </div>
          </div>
        )}

        <div className="text-xs font-semibold text-ink-faint mb-2">Choose a time</div>
        <div className="flex gap-2 flex-wrap mb-3">
          {TIME_SLOTS.map((t) => (
            <button key={t} onClick={() => { setSlot(t); setCustomDate(""); setCustomTime(""); }} className={`flex items-center gap-1.5 px-3 py-2 rounded-md border text-xs ${slot === t ? "border-accent bg-accent-dim text-accent" : "border-line text-ink-dim"}`}>
              <Calendar size={12} /> {t}
            </button>
          ))}
        </div>
        <div className="text-xs text-ink-faint mb-2">Or pick your own date and time</div>
        <div className="flex gap-2 flex-wrap items-center mb-5">
          <input type="date" value={customDate} onChange={(e) => { setCustomDate(e.target.value); setSlot(null); }} className="bg-navy border border-line rounded-md px-2.5 py-2 text-sm" />
          <input type="time" value={customTime} onChange={(e) => { setCustomTime(e.target.value); setSlot(null); }} className="bg-navy border border-line rounded-md px-2.5 py-2 text-sm" />
          {customSlot && <span className="text-xs text-accent">Selected: {customSlot}</span>}
        </div>

        {submitted ? (
          <Badge tone="good"><CheckCircle2 size={13} /> Request sent for {effectiveSlot} — pending confirmation</Badge>
        ) : (
          <Button icon={Stethoscope} disabled={!effectiveSlot} onClick={handleRequest}>Request Appointment</Button>
        )}
      </Panel>

      <Panel>
        <div className="text-sm font-semibold mb-3">Your consultation requests</div>
        {history.length === 0 ? (
          <EmptyState text="No consultation requests yet." />
        ) : (
          history.map((c) => (
            <div key={c.id} className="flex justify-between items-center text-sm py-2 border-b border-line last:border-0">
              <span>{c.requestedFor} · {c.mode === "in-person" ? "In person" : `Remote (${c.remoteType})`}</span>
              <Badge tone={c.status === "completed" ? "good" : c.status === "scheduled" ? "accent" : "warn"}>{c.status}</Badge>
            </div>
          ))
        )}
      </Panel>
    </div>
  );
}
