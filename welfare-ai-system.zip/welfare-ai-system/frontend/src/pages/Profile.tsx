import { useState, useEffect } from "react";
import { Camera, Bell, Shield } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Panel, PageHeader, Badge } from "../components/ui";

export default function Profile() {
  const { user } = useAuth();
  const [cameraPermission, setCameraPermission] = useState<string>("unknown");

  useEffect(() => {
    if (navigator.permissions && (navigator.permissions as any).query) {
      navigator.permissions.query({ name: "camera" as PermissionName })
        .then((r) => setCameraPermission(r.state))
        .catch(() => setCameraPermission("unknown"));
    }
  }, []);

  if (!user) return null;

  return (
    <div>
      <PageHeader title="Profile" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl">
        <Panel>
          <div className="text-sm font-semibold mb-4">Personnel details</div>
          <Row label="Personnel ID" value={user.id} />
          <Row label="Name" value={user.name} />
          <Row label="Role" value={user.role === "admin" ? "Welfare Officer" : "Personnel"} />
          <Row label="Unit / Department" value={user.unit || "—"} />
        </Panel>

        <Panel>
          <div className="text-sm font-semibold mb-4 flex items-center gap-2"><Shield size={14} /> Privacy settings</div>
          <div className="flex justify-between items-center text-sm mb-3">
            <span className="flex items-center gap-2 text-ink-dim"><Camera size={14} /> Camera permission</span>
            <Badge tone={cameraPermission === "granted" ? "good" : cameraPermission === "denied" ? "bad" : "warn"}>
              {cameraPermission}
            </Badge>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="flex items-center gap-2 text-ink-dim"><Bell size={14} /> Screening reminders</span>
            <Badge tone="good">Enabled</Badge>
          </div>
          <p className="text-xs text-ink-faint mt-4 leading-relaxed">
            Your individual screening responses are only visible to you. Welfare officers can see aggregate risk
            categories, not your detailed answers, unless you request a consultation.
          </p>
        </Panel>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-sm py-2 border-b border-line last:border-0">
      <span className="text-ink-faint">{label}</span>
      <span>{value}</span>
    </div>
  );
}
