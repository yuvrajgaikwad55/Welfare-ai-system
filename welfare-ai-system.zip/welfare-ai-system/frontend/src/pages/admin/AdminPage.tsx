import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ChevronRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import {
  getRoster, getAdminStats, getLatestScreening, getAlerts, updateAlertStatus, getAuditLogs,
} from "../lib/store";
import { riskOf } from "../lib/scoring";
import { Panel, StatCard, Badge, PageHeader, EmptyState, toneForScore } from "../components/ui";

export default function Admin() {
  const { user } = useAuth();
  const { tab } = useParams();
  const activeTab = tab || "overview";

  if (!user || user.role !== "admin") {
    return (
      <div>
        <PageHeader title="Access restricted" />
        <EmptyState text="This section is only available to authorized Welfare Officers." />
      </div>
    );
  }

  return (
    <div>
      {activeTab === "overview" && <OverviewTab />}
      {activeTab === "personnel" && <PersonnelTab />}
      {activeTab === "analytics" && <AdminAnalyticsTab />}
      {activeTab === "alerts" && <AlertsTab actorId={user.id} />}
      {activeTab === "reports" && <AdminReportsTab />}
      {activeTab === "audit-logs" && <AuditLogsTab />}
    </div>
  );
}

function OverviewTab() {
  const stats = getAdminStats();
  return (
    <div>
      <PageHeader title="Overview" sub="Aggregate welfare data — individual responses remain private." />
      <div className="flex flex-wrap gap-4 mb-6">
        <StatCard label="Total Personnel" value={stats.totalPersonnel} />
        <StatCard label="Screenings Completed" value={stats.screeningsCompleted} />
        <StatCard label="Low Concern" value={stats.low} tone="good" />
        <StatCard label="Moderate Concern" value={stats.moderate} tone="warn" />
        <StatCard label="Higher Concern" value={stats.high} tone="bad" />
        <StatCard label="Pending Follow-ups" value={stats.pendingFollowUps} tone="warn" />
      </div>
      <Panel>
        <div className="text-sm font-semibold mb-4">Risk distribution</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={[{ name: "Low", value: stats.low }, { name: "Moderate", value: stats.moderate }, { name: "Higher", value: stats.high }]}>
            <CartesianGrid stroke="#1E2C3D" vertical={false} />
            <XAxis dataKey="name" stroke="#5E7188" fontSize={12} tickLine={false} />
            <YAxis stroke="#5E7188" fontSize={12} tickLine={false} axisLine={false} width={28} />
            <Tooltip contentStyle={{ background: "#1B2838", border: "1px solid #26374B", borderRadius: 6 }} />
            <Bar dataKey="value" fill="#4C93C7" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Panel>
    </div>
  );
}

function PersonnelTab() {
  const navigate = useNavigate();
  const roster = getRoster();
  return (
    <div>
      <PageHeader title="Personnel" sub="Aggregate risk only — detailed answers are private to each individual." />
      <Panel>
        <div className="grid grid-cols-4 gap-2 text-xs text-ink-faint pb-2 border-b border-line mb-1">
          <div>ID</div><div>Name</div><div>Last screening</div><div>Risk</div>
        </div>
        {roster.map((r) => {
          const latest = getLatestScreening(r.id);
          const risk = latest ? riskOf(latest.overall) : null;
          return (
            <div key={r.id} className="grid grid-cols-4 gap-2 text-sm items-center py-2.5 border-b border-line last:border-0">
              <div className="text-ink-dim">{r.id}</div>
              <div>{r.name}</div>
              <div className="text-ink-faint">{latest ? new Date(latest.date).toLocaleDateString() : "No screening yet"}</div>
              <div>{risk ? <Badge tone={toneForScore(latest!.overall)}>{risk.label}</Badge> : <span className="text-ink-faint text-xs">—</span>}</div>
            </div>
          );
        })}
      </Panel>
      <p className="text-xs text-ink-faint mt-3">
        Per privacy policy, category-level answers are not shown here. A full profile view requires the
        individual's consent via a consultation request.
      </p>
    </div>
  );
}

function AdminAnalyticsTab() {
  const roster = getRoster();
  const rows = roster.map((r) => {
    const s = getLatestScreening(r.id);
    return { name: r.name, score: s?.overall ?? 0 };
  }).filter((r) => r.score > 0);

  return (
    <div>
      <PageHeader title="Team Analytics" sub="Based on each person's latest submitted screening." />
      <Panel>
        <div className="text-sm font-semibold mb-4">Latest wellness indicator by person</div>
        {rows.length ? (
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={rows}>
              <CartesianGrid stroke="#1E2C3D" vertical={false} />
              <XAxis dataKey="name" stroke="#5E7188" fontSize={11} tickLine={false} />
              <YAxis stroke="#5E7188" fontSize={11} domain={[0, 100]} tickLine={false} axisLine={false} width={28} />
              <Tooltip contentStyle={{ background: "#1B2838", border: "1px solid #26374B", borderRadius: 6 }} />
              <Bar dataKey="score" fill="#4C93C7" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <EmptyState text="No screenings recorded yet." />
        )}
      </Panel>
    </div>
  );
}

function AlertsTab({ actorId }: { actorId: string }) {
  const [, force] = useState(0);
  const alerts = getAlerts();

  function act(id: string, status: "acknowledged" | "assigned" | "resolved") {
    updateAlertStatus(id, status, actorId);
    force((n) => n + 1);
  }

  return (
    <div>
      <PageHeader title="Alerts" sub="Wellbeing follow-up flags — never an automatic diagnosis." />
      <Panel>
        {alerts.length === 0 ? (
          <EmptyState text="No alerts at this time." />
        ) : (
          alerts.map((a) => (
            <div key={a.id} className="flex justify-between items-center py-3 border-b border-line last:border-0">
              <div>
                <div className="text-sm">{a.level === "priority-follow-up" ? "🔴" : "🟡"} {a.message}</div>
                <div className="text-xs text-ink-faint mt-0.5">{a.userId} · {new Date(a.createdAt).toLocaleString()}</div>
              </div>
              <div className="flex gap-2 items-center">
                <Badge tone={a.status === "resolved" ? "good" : a.status === "open" ? "warn" : "accent"}>{a.status}</Badge>
                {a.status === "open" && <button onClick={() => act(a.id, "acknowledged")} className="text-xs text-accent hover:underline">Acknowledge</button>}
                {a.status === "acknowledged" && <button onClick={() => act(a.id, "assigned")} className="text-xs text-accent hover:underline">Assign</button>}
                {a.status === "assigned" && <button onClick={() => act(a.id, "resolved")} className="text-xs text-accent hover:underline">Resolve</button>}
              </div>
            </div>
          ))
        )}
      </Panel>
    </div>
  );
}

function AdminReportsTab() {
  const roster = getRoster();
  const navigate = useNavigate();
  return (
    <div>
      <PageHeader title="Reports" sub="Jump into an individual's report only with proper authorization context." />
      <Panel>
        {roster.map((r) => {
          const latest = getLatestScreening(r.id);
          return (
            <div key={r.id} className="flex justify-between items-center py-2.5 border-b border-line last:border-0 text-sm">
              <span>{r.name} ({r.id})</span>
              <span className="text-ink-faint flex items-center gap-1">
                {latest ? `${latest.overall}/100` : "No data"} <ChevronRight size={14} />
              </span>
            </div>
          );
        })}
      </Panel>
    </div>
  );
}

function AuditLogsTab() {
  const logs = getAuditLogs();
  return (
    <div>
      <PageHeader title="Audit Logs" />
      <Panel className="max-h-[60vh] overflow-y-auto">
        {logs.length === 0 ? (
          <EmptyState text="No activity recorded yet." />
        ) : (
          logs.map((l) => (
            <div key={l.id} className="flex justify-between text-xs py-2 border-b border-line last:border-0">
              <span className="text-ink-dim">{l.actorId} · {l.action}{l.target ? ` (${l.target})` : ""}</span>
              <span className="text-ink-faint">{new Date(l.createdAt).toLocaleString()}</span>
            </div>
          ))
        )}
      </Panel>
    </div>
  );
}
