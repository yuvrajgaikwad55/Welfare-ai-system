import { useNavigate } from "react-router-dom";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ClipboardList, Camera, FileText } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getLatestScreening, getWellnessTrend } from "../lib/store";
import { riskOf, consultationRecommendationFor } from "../lib/scoring";
import { Panel, StatCard, Button, PageHeader, EmptyState, toneForScore } from "../components/ui";

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const latest = user ? getLatestScreening(user.id) : null;
  const trend = user ? getWellnessTrend(user.id, 30) : [];
  const risk = latest ? riskOf(latest.overall) : null;
  const rec = latest ? consultationRecommendationFor(latest.overall) : null;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";

  return (
    <div>
      <PageHeader title={`${greeting} 👋`} sub="Your wellness overview" />

      <div className="flex gap-4 flex-wrap mb-6">
        <StatCard label="🧠 Wellness Indicator" value={latest ? `${latest.overall}/100` : "—"} tone={latest ? toneForScore(latest.overall) : "accent"} />
        <StatCard label="📊 Stress Risk" value={risk ? risk.label : "No data yet"} tone={latest ? toneForScore(latest.overall) : "accent"} />
        <StatCard label="😴 Recovery" value={latest ? `${latest.categoryScores["Sleep & Recovery"] ?? "—"}%` : "—"} />
        <StatCard label="😊 Expression Signal" value="Optional" sub="See Camera Check" />
        <StatCard label="📅 Last Screening" value={latest ? new Date(latest.date).toLocaleDateString() : "None yet"} />
      </div>

      <div className="flex gap-4 flex-wrap mb-6">
        <Button icon={ClipboardList} onClick={() => navigate("/screening")}>Start Screening</Button>
        <Button variant="secondary" icon={Camera} onClick={() => navigate("/camera")}>Camera Check</Button>
        <Button variant="secondary" icon={FileText} onClick={() => navigate("/reports")}>View Report</Button>
      </div>

      <Panel className="mb-6">
        <div className="text-sm font-semibold mb-4">Wellness trend — last 30 days</div>
        {trend.length >= 2 ? (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={trend}>
              <CartesianGrid stroke="#1E2C3D" vertical={false} />
              <XAxis dataKey="date" stroke="#5E7188" fontSize={11} tickLine={false} />
              <YAxis stroke="#5E7188" fontSize={11} domain={[0, 100]} tickLine={false} axisLine={false} width={28} />
              <Tooltip contentStyle={{ background: "#1B2838", border: "1px solid #26374B", borderRadius: 6, fontSize: 12 }} />
              <Line type="monotone" dataKey="overall" stroke="#4C93C7" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <EmptyState text="Complete at least two screenings to see your wellness trend here." />
        )}
      </Panel>

      {latest && rec && (
        <Panel>
          <div className="text-sm font-semibold mb-2">Recent recommendation</div>
          <p className="text-sm text-ink-dim leading-relaxed">{rec.note}</p>
          <p className="text-xs text-ink-faint mt-2">Suggested: {rec.type} with {rec.professional} ({rec.urgency})</p>
        </Panel>
      )}
    </div>
  );
}
