import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import { Layout } from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Screening from "./pages/Screening";
import CameraCheck from "./pages/Camera";
import Analytics from "./pages/Analytics";
import Reports from "./pages/Reports";
import Consultations from "./pages/Consultations";
import Profile from "./pages/Profile";
import Admin from "./pages/admin/AdminPage";

function Protected({ children, adminOnly = false }: { children: JSX.Element; adminOnly?: boolean }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== "admin") return <Navigate to="/dashboard" replace />;
  return <Layout>{children}</Layout>;
}

export default function App() {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} /> : <Login />} />

      <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
      <Route path="/screening" element={<Protected><Screening /></Protected>} />
      <Route path="/camera" element={<Protected><CameraCheck /></Protected>} />
      <Route path="/analytics" element={<Protected><Analytics /></Protected>} />
      <Route path="/reports" element={<Protected><Reports /></Protected>} />
      <Route path="/consultations" element={<Protected><Consultations /></Protected>} />
      <Route path="/profile" element={<Protected><Profile /></Protected>} />

      <Route path="/admin" element={<Protected adminOnly><Admin /></Protected>} />
      <Route path="/admin/:tab" element={<Protected adminOnly><Admin /></Protected>} />

      <Route path="*" element={<Navigate to={user ? (user.role === "admin" ? "/admin" : "/dashboard") : "/login"} replace />} />
    </Routes>
  );
}
