import { ReactNode } from "react";
import { LucideIcon } from "lucide-react";

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`bg-navy-surface border border-line rounded-lg p-5 ${className}`}>
      {children}
    </div>
  );
}

export function Badge({
  children,
  tone = "accent",
}: {
  children: ReactNode;
  tone?: "good" | "warn" | "bad" | "accent";
}) {
  const toneClasses: Record<string, string> = {
    good: "bg-good-dim text-good border-good/40",
    warn: "bg-warn-dim text-warn border-warn/40",
    bad: "bg-bad-dim text-bad border-bad/40",
    accent: "bg-accent-dim text-accent border-accent/40",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border ${toneClasses[tone]}`}>
      {children}
    </span>
  );
}

export function Button({
  children,
  icon: Icon,
  variant = "primary",
  onClick,
  disabled,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  icon?: LucideIcon;
  variant?: "primary" | "secondary" | "ghost";
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const base = "inline-flex items-center gap-2 px-4 py-2.5 rounded-md text-sm font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed";
  const variants: Record<string, string> = {
    primary: "bg-accent text-white hover:bg-accent/90",
    secondary: "bg-navy-raised border border-line text-ink hover:border-accent",
    ghost: "text-ink-dim hover:text-ink",
  };
  return (
    <button type={type} className={`${base} ${variants[variant]} ${className}`} onClick={onClick} disabled={disabled}>
      {Icon && <Icon size={16} />}
      {children}
    </button>
  );
}

export function StatCard({
  label,
  value,
  sub,
  tone = "accent",
}: {
  label: string;
  value: string | number;
  sub?: string;
  tone?: "good" | "warn" | "bad" | "accent";
}) {
  const toneClasses: Record<string, string> = {
    good: "border-l-good",
    warn: "border-l-warn",
    bad: "border-l-bad",
    accent: "border-l-accent",
  };
  return (
    <Panel className={`flex-1 min-w-[160px] border-l-[3px] ${toneClasses[tone]}`}>
      <div className="text-xs text-ink-faint mb-1">{label}</div>
      <div className="text-2xl font-bold text-ink">{value}</div>
      {sub && <div className="text-xs text-ink-faint mt-1">{sub}</div>}
    </Panel>
  );
}

export function ProgressBar({ value, tone = "accent" }: { value: number; tone?: "good" | "warn" | "bad" | "accent" }) {
  const toneClasses: Record<string, string> = {
    good: "bg-good", warn: "bg-warn", bad: "bg-bad", accent: "bg-accent",
  };
  return (
    <div className="w-full h-2 rounded-full bg-navy-raised overflow-hidden">
      <div className={`h-full rounded-full ${toneClasses[tone]}`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function PageHeader({
  title,
  sub,
  right,
}: {
  title: string;
  sub?: string;
  right?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between flex-wrap gap-3 mb-5">
      <div>
        <h1 className="text-xl font-bold text-ink">{title}</h1>
        {sub && <p className="text-sm text-ink-faint mt-1">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function EmptyState({ text }: { text: string }) {
  return (
    <div className="text-sm text-ink-faint text-center py-10 border border-dashed border-line rounded-lg">
      {text}
    </div>
  );
}

export function toneForScore(score: number): "good" | "warn" | "bad" {
  if (score >= 72) return "good";
  if (score >= 50) return "warn";
  return "bad";
}
