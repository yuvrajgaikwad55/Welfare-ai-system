import { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  Shield, LayoutDashboard, ClipboardList, Camera, BarChart3, Stethoscope,
  FileText, User as UserIcon, LogOut, Users, Bell, ScrollText,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

const PERSONNEL_NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/screening", label: "Screening", icon: ClipboardList },
  { to: "/camera", label: "Camera Check", icon: Camera },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/consultations", label: "Consultations", icon: Stethoscope },
  { to: "/reports", label: "Reports", icon: FileText },
  { to: "/profile", label: "Profile", icon: UserIcon },
];

const ADMIN_NAV = [
  { to: "/admin", label: "Overview", icon: LayoutDashboard },
  { to: "/admin/personnel", label: "Personnel", icon: Users },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/admin/alerts", label: "Alerts", icon: Bell },
  { to: "/admin/reports", label: "Reports", icon: FileText },
  { to: "/admin/audit-logs", label: "Audit Logs", icon: ScrollText },
];

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const nav = user?.role === "admin" ? ADMIN_NAV : PERSONNEL_NAV;

  return (
    <div className="flex min-h-screen bg-navy text-ink">
      <aside className="no-print w-56 shrink-0 bg-navy-surface border-r border-line flex flex-col p-3">
        <div className="flex items-center gap-2 px-2 py-3 mb-2">
          <Shield size={20} className="text-accent" />
          <span className="font-bold text-sm">Welfare AI</span>
        </div>
        <nav className="flex-1 flex flex-col gap-1">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm transition ${
                  isActive ? "bg-accent-dim text-accent font-semibold" : "text-ink-dim hover:bg-navy-raised"
                }`
              }
            >
              <item.icon size={16} />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={() => { logout(); navigate("/login"); }}
          className="flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-ink-dim hover:bg-navy-raised"
        >
          <LogOut size={16} /> Logout
        </button>
      </aside>
      <div className="flex-1 flex flex-col min-w-0">
        <header className="no-print h-14 border-b border-line flex items-center justify-between px-6 shrink-0">
          <div className="text-sm text-ink-dim">
            {user?.role === "admin" ? "Welfare Officer Dashboard" : "Personnel Welfare AI"}
          </div>
          <div className="text-sm font-medium">{user?.name} <span className="text-ink-faint">· {user?.id}</span></div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
