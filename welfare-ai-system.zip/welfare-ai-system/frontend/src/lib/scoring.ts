import { RiskInfo, CategoryScores } from "../types";

// Configurable thresholds — tune these for your deployment.
export const RISK_THRESHOLDS = {
  low: 72, // score >= 72 -> low concern
  moderate: 50, // score >= 50 -> moderate concern, below -> high concern
};

export function riskOf(score: number): RiskInfo {
  if (score >= RISK_THRESHOLDS.low) return { key: "low", label: "Low concern" };
  if (score >= RISK_THRESHOLDS.moderate) return { key: "moderate", label: "Moderate concern" };
  return { key: "high", label: "Higher concern" };
}

export const QUESTIONS: Record<string, string[]> = {
  "Sleep & Recovery": [
    "How well did you sleep over the past week?",
    "How rested do you feel after waking?",
    "Have irregular duty hours affected your sleep?",
  ],
  Workload: [
    "How manageable is your current workload?",
    "How often do you feel mentally exhausted after duty?",
    "How difficult is it to concentrate during tasks?",
  ],
  Mood: [
    "How would you describe your overall mood this week?",
    "How often have you felt unusually worried or tense?",
    "How connected do you feel with your colleagues?",
  ],
  "Social Support": [
    "How often do you get to communicate with family?",
    "Do you feel supported by the people around you?",
    "Do you have someone you can talk to about difficulties?",
  ],
  "Work-Life Balance": [
    "How much personal time do you get outside duty hours?",
    "How often does work interfere with personal plans?",
  ],
  "Recovery & Wellbeing": [
    "How would you rate your overall energy levels?",
    "How often do you get time to properly recover between duties?",
  ],
};

export const OPTIONS = [
  { v: 5, label: "Very good", emoji: "😊" },
  { v: 4, label: "Good", emoji: "🙂" },
  { v: 3, label: "Okay", emoji: "😐" },
  { v: 2, label: "Difficult", emoji: "😟" },
  { v: 1, label: "Very difficult", emoji: "😔" },
];

/** Turns raw 1-5 answers per category into 0-100 category scores. */
export function scoreCategories(answers: Record<string, Record<number, number>>): CategoryScores {
  const scores: CategoryScores = {};
  Object.keys(QUESTIONS).forEach((cat) => {
    const a = answers[cat] || {};
    const vals = Object.values(a);
    if (vals.length === 0) {
      scores[cat] = 0;
      return;
    }
    const avg = vals.reduce((s, v) => s + v, 0) / vals.length;
    scores[cat] = Math.round(avg * 20); // 1-5 -> 20-100
  });
  return scores;
}

export function overallFrom(categoryScores: CategoryScores): number {
  const vals = Object.values(categoryScores);
  if (vals.length === 0) return 0;
  return Math.round(vals.reduce((s, v) => s + v, 0) / vals.length);
}

/**
 * IMPORTANT: This produces screening/support language only.
 * It must never output a diagnostic claim (e.g. "you have depression").
 */
export function observationsFor(categoryScores: CategoryScores): string[] {
  const obs: string[] = [];
  if ((categoryScores["Sleep & Recovery"] ?? 100) < 65)
    obs.push("Sleep and recovery indicators are lower than ideal — consider prioritising rest.");
  if ((categoryScores["Workload"] ?? 100) < 65)
    obs.push("Workload responses suggest moderate to high pressure.");
  if ((categoryScores["Mood"] ?? 100) < 65)
    obs.push("Your responses indicate a higher level of wellbeing concern. Consider speaking with an appropriate qualified support professional.");
  if ((categoryScores["Social Support"] ?? 0) >= 70)
    obs.push("Social support appears relatively strong.");
  if (obs.length === 0) obs.push("Overall indicators are stable across the screened categories.");
  obs.push("This is a screening/support indicator, not a medical diagnosis — speak with a qualified professional if concerns persist.");
  return obs;
}

export function consultationRecommendationFor(score: number) {
  const risk = riskOf(score);
  if (risk.key === "high") {
    return {
      type: "Priority consultation",
      professional: "Unit Medical Officer / Counsellor",
      urgency: "Within 24–48 hours",
      note: "Wellbeing follow-up may be appropriate — a prompt check-in is recommended, in person where possible.",
    };
  }
  if (risk.key === "moderate") {
    return {
      type: "Routine consultation",
      professional: "Welfare Counsellor",
      urgency: "Within 1–2 weeks",
      note: "A routine check-in is suggested to review workload and recovery.",
    };
  }
  return {
    type: "Optional wellness check-in",
    professional: "Welfare Counsellor",
    urgency: "At your convenience",
    note: "No urgent concerns from current signals — a check-in remains available anytime you'd like to talk.",
  };
}
