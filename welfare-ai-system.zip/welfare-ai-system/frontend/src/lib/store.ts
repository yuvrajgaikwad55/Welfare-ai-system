import {
  User, Screening, ConsultationRequest, Alert, AuditLogEntry, CategoryScores,
} from "../types";
import { scoreCategories, overallFrom, observationsFor } from "./scoring";

/**
 * LOCAL DEV FALLBACK
 * ------------------
 * This module stores everything in the browser's localStorage under the
 * "welfare_ai_db" key, structured like a small relational database. It is
 * a stand-in for the real backend (see /backend) when you don't yet have
 * Supabase/Postgres credentials wired up.
 *
 * To switch to the real backend: replace the bodies of the functions below
 * with `fetch("/api/...")` calls — the function signatures already match
 * the REST endpoints implemented in backend/src/routes.
 */

const DB_KEY = "welfare_ai_db";

interface DB {
  users: User[];
  screenings: Screening[];
  consultations: ConsultationRequest[];
  alerts: Alert[];
  auditLogs: AuditLogEntry[];
}

const DEMO_ROSTER: User[] = [
  { id: "PN-2201", name: "You", role: "personnel", unit: "Alpha Company" },
  { id: "PN-1042", name: "R. Sharma", role: "personnel", unit: "Alpha Company" },
  { id: "PN-1077", name: "K. Verma", role: "personnel", unit: "Bravo Company" },
  { id: "PN-1103", name: "S. Iyer", role: "personnel", unit: "Bravo Company" },
  { id: "PN-1156", name: "A. Khan", role: "personnel", unit: "Charlie Company" },
  { id: "PN-1198", name: "M. Das", role: "personnel", unit: "Charlie Company" },
  { id: "ADM-01", name: "Welfare Officer", role: "admin", unit: "Welfare Cell" },
];

function loadDB(): DB {
  const raw = localStorage.getItem(DB_KEY);
  if (raw) {
    try {
      return JSON.parse(raw) as DB;
    } catch {
      // fall through to reseed if corrupted
    }
  }
  const fresh: DB = { users: DEMO_ROSTER, screenings: [], consultations: [], alerts: [], auditLogs: [] };
  localStorage.setItem(DB_KEY, JSON.stringify(fresh));
  return fresh;
}

function saveDB(db: DB) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
}

/* ---------------------------- Auth ---------------------------- */

// DEMO ONLY: plaintext demo password check. The real backend hashes
// passwords with bcrypt — see backend/src/routes/auth.js.
const DEMO_PASSWORD = "demo1234";

export async function login(personnelId: string, password: string): Promise<User> {
  const db = loadDB();
  const user = db.users.find((u) => u.id.toLowerCase() === personnelId.trim().toLowerCase());
  if (!user) throw new Error("Personnel ID not found. Try PN-2201 or ADM-01 (demo).");
  if (password !== DEMO_PASSWORD) throw new Error("Incorrect password. Demo password is 'demo1234'.");
  localStorage.setItem("welfare_ai_session", JSON.stringify(user));
  addAuditLog(user.id, "login");
  return user;
}

export function logout() {
  const raw = localStorage.getItem("welfare_ai_session");
  if (raw) {
    const user = JSON.parse(raw) as User;
    addAuditLog(user.id, "logout");
  }
  localStorage.removeItem("welfare_ai_session");
}

export function getSession(): User | null {
  const raw = localStorage.getItem("welfare_ai_session");
  return raw ? (JSON.parse(raw) as User) : null;
}

/* ------------------------- Screenings -------------------------- */

export async function submitScreening(
  userId: string,
  answers: Record<string, Record<number, number>>
): Promise<Screening> {
  const db = loadDB();
  const categoryScores: CategoryScores = scoreCategories(answers);
  const overall = overallFrom(categoryScores);
  const screening: Screening = {
    id: uid("SCR"),
    userId,
    date: new Date().toISOString(),
    categoryScores,
    overall,
    observations: observationsFor(categoryScores),
  };
  db.screenings.push(screening);

  // Auto-generate a follow-up alert for moderate/high concern, per spec §17.
  if (overall < 72) {
    db.alerts.push({
      id: uid("ALERT"),
      userId,
      level: overall < 50 ? "priority-follow-up" : "follow-up",
      message: overall < 50 ? "Priority follow-up recommended." : "Wellbeing follow-up may be appropriate.",
      status: "open",
      createdAt: new Date().toISOString(),
    });
  }
  saveDB(db);
  addAuditLog(userId, "submit_screening", screening.id);
  return screening;
}

export function getScreenings(userId: string): Screening[] {
  const db = loadDB();
  return db.screenings.filter((s) => s.userId === userId).sort((a, b) => b.date.localeCompare(a.date));
}

export function getAllScreenings(): Screening[] {
  return loadDB().screenings;
}

export function getLatestScreening(userId: string): Screening | null {
  const list = getScreenings(userId);
  return list.length ? list[0] : null;
}

/** Real trend data for charts — derived from actual stored screenings, not mock numbers. */
export function getWellnessTrend(userId: string, days: number): { date: string; overall: number }[] {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return getScreenings(userId)
    .filter((s) => new Date(s.date).getTime() >= cutoff)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((s) => ({ date: new Date(s.date).toLocaleDateString("en-IN", { day: "2-digit", month: "short" }), overall: s.overall }));
}

export function getCategoryTrend(userId: string, category: string, days: number) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return getScreenings(userId)
    .filter((s) => new Date(s.date).getTime() >= cutoff)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((s) => ({ date: new Date(s.date).toLocaleDateString("en-IN", { day: "2-digit", month: "short" }), value: s.categoryScores[category] ?? 0 }));
}

/* ------------------------- Consultations ------------------------ */

export async function requestConsultation(input: Omit<ConsultationRequest, "id" | "status" | "createdAt">): Promise<ConsultationRequest> {
  const db = loadDB();
  const request: ConsultationRequest = {
    ...input,
    id: uid("CONSULT"),
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  db.consultations.push(request);
  saveDB(db);
  addAuditLog(input.userId, "request_consultation", request.id);
  return request;
}

export function getConsultations(userId: string): ConsultationRequest[] {
  return loadDB().consultations.filter((c) => c.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/* ---------------------------- Roster ----------------------------- */

export function getRoster(): User[] {
  return loadDB().users.filter((u) => u.role === "personnel");
}

export function getUser(id: string): User | undefined {
  return loadDB().users.find((u) => u.id === id);
}

/* ---------------------------- Alerts ------------------------------ */

export function getAlerts(): Alert[] {
  return loadDB().alerts.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function updateAlertStatus(id: string, status: Alert["status"], actorId: string) {
  const db = loadDB();
  const alert = db.alerts.find((a) => a.id === id);
  if (alert) {
    alert.status = status;
    saveDB(db);
    addAuditLog(actorId, `alert_${status}`, id);
  }
}

/* -------------------------- Audit logs ----------------------------- */

function addAuditLog(actorId: string, action: string, target?: string) {
  const db = loadDB();
  db.auditLogs.push({ id: uid("LOG"), actorId, action, target, createdAt: new Date().toISOString() });
  saveDB(db);
}

export function getAuditLogs(): AuditLogEntry[] {
  return loadDB().auditLogs.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/* --------------------- Admin aggregate stats ------------------------ */

export function getAdminStats() {
  const db = loadDB();
  const roster = db.users.filter((u) => u.role === "personnel");
  const latestByUser = new Map<string, Screening>();
  db.screenings.forEach((s) => {
    const existing = latestByUser.get(s.userId);
    if (!existing || s.date > existing.date) latestByUser.set(s.userId, s);
  });
  const latest = Array.from(latestByUser.values());
  return {
    totalPersonnel: roster.length,
    screeningsCompleted: db.screenings.length,
    low: latest.filter((s) => s.overall >= 72).length,
    moderate: latest.filter((s) => s.overall >= 50 && s.overall < 72).length,
    high: latest.filter((s) => s.overall < 50).length,
    pendingFollowUps: db.alerts.filter((a) => a.status === "open").length,
  };
}
