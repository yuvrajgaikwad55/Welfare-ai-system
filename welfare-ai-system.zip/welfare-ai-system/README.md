# AI-Based Predictive Personnel Stress and Welfare Monitoring System

A demo-ready prototype for the SIH problem statement of the same name. Personnel/User and
Welfare/Admin Officer roles, real screening → scoring → analytics → PDF report pipeline,
consultation requests, alerts, and a **real, unrestricted browser camera check** — the
part that cannot work inside Claude's own Artifacts preview, and does not need to.

---

## 1. Project layout

```
welfare-ai-system/
├── frontend/     React + TypeScript + Tailwind + Recharts + Lucide (Vite)
└── backend/      Node + Express + JWT (optional — frontend runs standalone too)
```

The frontend works **on its own**, storing data in the browser's `localStorage` behind an
API-shaped module (`src/lib/store.ts`) — this is the "clean local dev fallback" for when you
don't yet have Supabase/Postgres credentials. The backend is a real, working Express + JWT
server with the matching REST routes and a JSON-file datastore, for when you want a genuine
server in the loop. Swapping the frontend from local storage to the backend is a matter of
replacing the function bodies in `store.ts` with `fetch("/api/...")` calls — the shapes
already match.

---

## 2. How to run locally

### Frontend only (fastest way to see everything, including the real camera)

```bash
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173** (must be `localhost`, not a raw IP, for camera access).

Demo login:
- Personnel: `PN-2201` / `demo1234`
- Admin: `ADM-01` / `demo1234`

### Backend (optional, for the real Express + JWT API)

```bash
cd backend
cp .env.example .env      # edit JWT_SECRET before any real deployment
npm install
npm run dev
```

The API listens on **http://localhost:4000**. It uses the same demo accounts/password. Data
is stored in `backend/src/db/data.json` (created automatically on first run) unless you wire
up `DATABASE_URL` / Supabase yourself — that part needs your own credentials, which I don't
have access to from here.

I could not run `npm install` or start either server myself in this environment — there's no
network access from where this code was written, so it has not been executed or type-checked
here. Please run it on your machine and let me know if anything doesn't compile; I'm glad to
fix it once you can show me an actual error.

---

## 3. How to test the camera specifically

The camera will **not** work inside Claude's chat/artifact preview — that iframe blocks
camera access at the browser's permissions-policy level, regardless of what the code does.
That's expected and is not a bug in this project.

To verify it for real:

1. `cd frontend && npm install && npm run dev`
2. Open `http://localhost:5173` in Chrome or Firefox — this is a secure context, so the
   camera API is available.
3. Log in, go to **Camera Check**.
4. Confirm the page does **not** ask for camera permission automatically.
5. Click **📷 Start Camera** — your browser's real permission prompt should appear.
6. Click **Allow** — you should see your actual live webcam feed, a "🟢 Camera Active"
   badge, and a **Stop Camera** button.
7. Click **Stop Camera** — the video stops and the underlying tracks are released (check
   your browser/OS camera indicator light turns off).
8. Test error handling by:
   - Denying the permission prompt → should show the "permission is blocked" message.
   - Opening the page with no camera connected (or disabling it in OS settings) →
     "No camera device was detected."
   - Opening another app using the camera (Zoom/Meet) first → "camera may already be in
     use" message.
9. Expand **Camera diagnostics** at the bottom of the page and confirm: Camera API =
   Available, Secure Context = Yes, Permission reflects your last action, Camera Stream =
   Active/Inactive matches what's on screen.

For HTTPS deployment testing, repeat the same steps against your deployed `https://` URL.

---

## 4. How to deploy

**Frontend** (static site): `npm run build` in `frontend/` produces `dist/`. Deploy that to
Vercel, Netlify, GitHub Pages, or any static host — all serve over HTTPS by default, which
satisfies the camera's secure-context requirement.

**Backend** (if used): deploy `backend/` to Render, Railway, Fly.io, or a VM. Set the
environment variables from `.env.example` in your host's dashboard — never commit a real
`.env` file. Point `CORS_ORIGIN` at your deployed frontend URL.

**Database**: if you want real persistence beyond the JSON-file fallback, provision a
Supabase or Postgres instance and set `DATABASE_URL` / `SUPABASE_URL` /
`SUPABASE_SERVICE_ROLE_KEY`. Wiring the actual queries is not done in this pass — the
JSON-file store in `backend/src/db/jsonStore.js` is written so swapping its `readDB`/`writeDB`
functions for real SQL calls is a contained change.

---

## 5. Environment variables

`backend/.env.example`:
| Variable | Purpose |
|---|---|
| `JWT_SECRET` | Signs session tokens. Must be a long random string in production. |
| `PORT` | Port the API listens on (default 4000). |
| `CORS_ORIGIN` | Comma-separated allowed frontend origins. |
| `DATABASE_URL`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` | Optional — leave blank to use the local JSON-file fallback. |

No frontend environment variables are required for local-storage mode.

---

## 6. What's implemented vs. stubbed

**Fully working:** login (demo accounts), role-based navigation, multi-step screening with
real scoring, wellness/category charts driven from actual stored screenings (not fake
numbers), real camera access with full error handling and a diagnostics panel, PDF report
generation and download (dependency-free PDF writer, no external library needed), print
view, consultation requests with custom or preset date/time and a contact number, admin
overview/personnel/analytics/alerts/audit-log views, and an audit log of key actions.

**Stubbed / demo-labelled on purpose:**
- The "AI-assisted expression signal" on the Camera Check page generates readings locally
  rather than running a real facial-expression model — clearly labeled as a demo/prototype,
  and architected so a real model (e.g., a client-side TensorFlow.js model) could be dropped
  into the same `useEffect` without touching anything else.
- The backend's database is a local JSON file unless you connect a real Postgres/Supabase
  instance yourself.
- Password hashing, JWT auth, and role checks are implemented for real in the backend, but
  I have not been able to execute or penetration-test this code — treat it as a solid
  starting point, not an audited production auth system.

---

## 7. Remaining limitations (please read)

- **I did not run this code.** This sandbox has no network access, so `npm install` fails
  here, and there's no way for me to start a dev server or run a type-check. Everything
  above is written to be correct based on the APIs involved, but you are the first one to
  actually execute it — please tell me the exact error if something doesn't run, and I'll
  fix it against real output rather than guessing again.
- No SMS/email/notification delivery is wired up — alerts and consultation requests update
  in-app status only.
- No real facial-expression model is included (see above).
- The JWT backend and the localStorage frontend are two independent implementations of the
  same API shape — they are not wired together yet. Pick one to be your source of truth
  and I can help connect them.
