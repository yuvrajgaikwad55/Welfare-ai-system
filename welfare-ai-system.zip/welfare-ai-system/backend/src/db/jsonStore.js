import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import bcrypt from "bcryptjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, "data.json");

function seed() {
  const demoHash = bcrypt.hashSync("demo1234", 8);
  return {
    users: [
      { id: "PN-2201", name: "You", role: "personnel", unit: "Alpha Company", passwordHash: demoHash },
      { id: "PN-1042", name: "R. Sharma", role: "personnel", unit: "Alpha Company", passwordHash: demoHash },
      { id: "PN-1077", name: "K. Verma", role: "personnel", unit: "Bravo Company", passwordHash: demoHash },
      { id: "ADM-01", name: "Welfare Officer", role: "admin", unit: "Welfare Cell", passwordHash: demoHash },
    ],
    screenings: [],
    consultations: [],
    alerts: [],
    auditLogs: [],
  };
}

export function readDB() {
  if (!fs.existsSync(DATA_FILE)) {
    const fresh = seed();
    fs.writeFileSync(DATA_FILE, JSON.stringify(fresh, null, 2));
    return fresh;
  }
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
}

export function writeDB(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

export function uid(prefix) {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
}
