export const RISK_THRESHOLDS = { low: 72, moderate: 50 };

export function riskOf(score) {
  if (score >= RISK_THRESHOLDS.low) return { key: "low", label: "Low concern" };
  if (score >= RISK_THRESHOLDS.moderate) return { key: "moderate", label: "Moderate concern" };
  return { key: "high", label: "Higher concern" };
}

export function scoreCategories(answers) {
  const scores = {};
  Object.keys(answers || {}).forEach((cat) => {
    const vals = Object.values(answers[cat] || {});
    if (!vals.length) { scores[cat] = 0; return; }
    const avg = vals.reduce((s, v) => s + v, 0) / vals.length;
    scores[cat] = Math.round(avg * 20);
  });
  return scores;
}

export function overallFrom(categoryScores) {
  const vals = Object.values(categoryScores);
  if (!vals.length) return 0;
  return Math.round(vals.reduce((s, v) => s + v, 0) / vals.length);
}

export function observationsFor(categoryScores) {
  const obs = [];
  if ((categoryScores["Sleep & Recovery"] ?? 100) < 65) obs.push("Sleep and recovery indicators are lower than ideal — consider prioritising rest.");
  if ((categoryScores["Workload"] ?? 100) < 65) obs.push("Workload responses suggest moderate to high pressure.");
  if ((categoryScores["Mood"] ?? 100) < 65) obs.push("Your responses indicate a higher level of wellbeing concern. Consider speaking with an appropriate qualified support professional.");
  if (obs.length === 0) obs.push("Overall indicators are stable across the screened categories.");
  obs.push("This is a screening/support indicator, not a medical diagnosis.");
  return obs;
}
