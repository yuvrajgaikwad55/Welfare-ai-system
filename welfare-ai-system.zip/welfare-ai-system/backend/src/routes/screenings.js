import { Router } from "express";
import { readDB, writeDB, uid } from "../db/jsonStore.js";
import { requireAuth } from "../middleware/auth.js";
import { scoreCategories, overallFrom, observationsFor } from "../utils/scoring.js";

const router = Router();

router.post("/", requireAuth, (req, res) => {
  const { answers } = req.body || {};
  if (!answers) return res.status(400).json({ error: "answers is required." });

  const db = readDB();
  const categoryScores = scoreCategories(answers);
  const overall = overallFrom(categoryScores);
  const screening = {
    id: uid("SCR"),
    userId: req.user.id,
    date: new Date().toISOString(),
    categoryScores,
    overall,
    observations: observationsFor(categoryScores),
  };
  db.screenings.push(screening);

  if (overall < 72) {
    db.alerts.push({
      id: uid("ALERT"),
      userId: req.user.id,
      level: overall < 50 ? "priority-follow-up" : "follow-up",
      message: overall < 50 ? "Priority follow-up recommended." : "Wellbeing follow-up may be appropriate.",
      status: "open",
      createdAt: new Date().toISOString(),
    });
  }

  db.auditLogs.push({ id: uid("LOG"), actorId: req.user.id, action: "submit_screening", target: screening.id, createdAt: new Date().toISOString() });
  writeDB(db);
  res.status(201).json(screening);
});

router.get("/me", requireAuth, (req, res) => {
  const db = readDB();
  const mine = db.screenings.filter((s) => s.userId === req.user.id).sort((a, b) => b.date.localeCompare(a.date));
  res.json(mine);
});

export default router;
