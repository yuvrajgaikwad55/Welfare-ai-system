import { Router } from "express";
import bcrypt from "bcryptjs";
import { readDB } from "../db/jsonStore.js";
import { signToken } from "../middleware/auth.js";

const router = Router();

router.post("/login", (req, res) => {
  const { id, password } = req.body || {};
  if (!id || !password) return res.status(400).json({ error: "Personnel ID and password are required." });

  const db = readDB();
  const user = db.users.find((u) => u.id.toLowerCase() === String(id).trim().toLowerCase());
  if (!user) return res.status(401).json({ error: "Personnel ID not found." });

  const valid = bcrypt.compareSync(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: "Incorrect password." });

  const token = signToken(user);
  res.json({ token, user: { id: user.id, name: user.name, role: user.role, unit: user.unit } });
});

export default router;
