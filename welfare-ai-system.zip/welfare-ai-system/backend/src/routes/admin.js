import { Router } from "express";
import { readDB, writeDB, uid } from "../db/jsonStore.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();
router.use(requireAuth, requireRole("admin"));

router.get("/roster", (req, res) => {
  const db = readDB();
  res.json(db.users.filter((u) => u.role === "personnel").map(({ passwordHash, ...u }) => u));
});

router.get("/stats", (req, res) => {
  const db = readDB();
  const roster = db.users.filter((u) => u.role === "personnel");
  const latestByUser = new Map();
  db.screenings.forEach((s) => {
    const existing = latestByUser.get(s.userId);
    if (!existing || s.date > existing.date) latestByUser.set(s.userId, s);
  });
  const latest = Array.from(latestByUser.values());
  res.json({
    totalPersonnel: roster.length,
    screeningsCompleted: db.screenings.length,
    low: latest.filter((s) => s.overall >= 72).length,
    moderate: latest.filter((s) => s.overall >= 50 && s.overall < 72).length,
    high: latest.filter((s) => s.overall < 50).length,
    pendingFollowUps: db.alerts.filter((a) => a.status === "open").length,
  });
});

router.get("/alerts", (req, res) => {
  res.json(readDB().alerts.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
});

router.patch("/alerts/:id", (req, res) => {
  const { status } = req.body || {};
  const db = readDB();
  const alert = db.alerts.find((a) => a.id === req.params.id);
  if (!alert) return res.status(404).json({ error: "Alert not found." });
  alert.status = status;
  db.auditLogs.push({ id: uid("LOG"), actorId: req.user.id, action: `alert_${status}`, target: alert.id, createdAt: new Date().toISOString() });
  writeDB(db);
  res.json(alert);
});

router.get("/audit-logs", (req, res) => {
  res.json(readDB().auditLogs.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
});

export default router;
