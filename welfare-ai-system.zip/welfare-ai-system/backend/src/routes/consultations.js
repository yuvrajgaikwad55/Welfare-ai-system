import { Router } from "express";
import { readDB, writeDB, uid } from "../db/jsonStore.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.post("/", requireAuth, (req, res) => {
  const { mode, locationId, remoteType, requestedFor } = req.body || {};
  if (!mode || !requestedFor) return res.status(400).json({ error: "mode and requestedFor are required." });

  const db = readDB();
  const request = {
    id: uid("CONSULT"),
    userId: req.user.id,
    mode, locationId, remoteType, requestedFor,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  db.consultations.push(request);
  db.auditLogs.push({ id: uid("LOG"), actorId: req.user.id, action: "request_consultation", target: request.id, createdAt: new Date().toISOString() });
  writeDB(db);
  res.status(201).json(request);
});

router.get("/me", requireAuth, (req, res) => {
  const db = readDB();
  res.json(db.consultations.filter((c) => c.userId === req.user.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
});

export default router;
