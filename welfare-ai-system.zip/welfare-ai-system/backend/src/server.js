import "dotenv/config";
import express from "express";
import cors from "cors";
import authRoutes from "./routes/auth.js";
import screeningRoutes from "./routes/screenings.js";
import consultationRoutes from "./routes/consultations.js";
import adminRoutes from "./routes/admin.js";

const app = express();
const PORT = process.env.PORT || 4000;
const CORS_ORIGIN = (process.env.CORS_ORIGIN || "http://localhost:5173").split(",");

app.use(cors({ origin: CORS_ORIGIN, credentials: true }));
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

app.use("/api/auth", authRoutes);
app.use("/api/screenings", screeningRoutes);
app.use("/api/consultations", consultationRoutes);
app.use("/api/admin", adminRoutes);

// Centralised error handler — never leak internals to the client.
app.use((err, req, res, next) => {
  console.error("[server error]", err);
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => {
  console.log(`Welfare AI backend listening on http://localhost:${PORT}`);
});
